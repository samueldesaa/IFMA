</div>
<footer>
    <p>&copy; 2025 | Developed by Samuel Chaves (versão 2) </p>
</footer>    
</body>
</html>