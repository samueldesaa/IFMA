class Sensor:
    def __init__(self):
        self.info = []
        self.ultimas_leituras = ""

    def agir(self, plantas):
        self.info = [(i, round(p.maturidade, 1), round(p.agua, 1), p.coletada) for i, p in enumerate(plantas)]
        criticas = [i for i, m, a, c in self.info if a < 20 and not c]
        self.ultimas_leituras = f"Plantas com pouca água: {criticas[:5]}"
