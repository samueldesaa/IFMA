import pygame
from agenteA import Irrigador
from agenteB import Colhedor
from agenteC import Sensor
from ambiente import Planta
from visual import *

pygame.init()
LARGURA, ALTURA = 1000, 600
tela = pygame.display.set_mode((LARGURA, ALTURA))
pygame.display.set_caption("Agricultura Automatizada")
fonte = pygame.font.SysFont("arial", 16)

plantas = [Planta(100 + (i % 5) * 120, 100 + (i // 5) * 100) for i in range(20)]
irrigador = Irrigador()
colhedor = Colhedor()
sensor = Sensor()
relogio = pygame.time.Clock()
rodando = True

while rodando:
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            rodando = False

    tela.fill((255, 255, 255))

    for planta in plantas:
        planta.atualizar()
    irrigador.agir(plantas)
    colhedor.agir(plantas)
    sensor.agir(plantas)

    for planta in plantas:
        desenhar_planta(tela, planta)
    desenhar_irrigador(tela, irrigador)
    desenhar_colhedor(tela, colhedor)
    desenhar_hud(tela, fonte, irrigador, colhedor, sensor, plantas)

    pygame.display.flip()
    relogio.tick(30)

pygame.quit()
