import pygame
AZUL = (70, 130, 180)

class Irrigador:
    def __init__(self):
        self.x, self.y = 0, 0
        self.ultima_acao = ""

    def agir(self, plantas):
        for planta in plantas:
            if planta.agua < 30 and not planta.coletada:
                planta.agua += 20
                self.x, self.y = planta.x, planta.y
                self.ultima_acao = f"Irrigou planta em ({planta.x}, {planta.y})"
                return
        self.ultima_acao = "Nenhuma planta irrigada"
