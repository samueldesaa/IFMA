import pygame

VERDE = (34, 139, 34)
AZUL = (70, 130, 180)
CINZA = (169, 169, 169)
AMARELO = (255, 215, 0)
PRETO = (0, 0, 0)

def desenhar_planta(tela, planta):
    cor = VERDE if not planta.coletada else CINZA
    tamanho = int(10 + planta.maturidade / 10)
    pygame.draw.circle(tela, cor, (planta.x, planta.y), tamanho)
    pygame.draw.rect(tela, AZUL, (planta.x - 10, planta.y + 10, planta.agua / 5, 5))

def desenhar_irrigador(tela, irrigador):
    pygame.draw.rect(tela, AZUL, (irrigador.x - 5, irrigador.y - 25, 10, 10))

def desenhar_colhedor(tela, colhedor):
    pygame.draw.rect(tela, AMARELO, (colhedor.x - 5, colhedor.y - 35, 10, 10))

def desenhar_hud(tela, fonte, irrigador, colhedor, sensor, plantas):
    pygame.draw.rect(tela, (230, 230, 230), (800, 0, 200, 600))
    tela.blit(fonte.render("INFORMAÇÕES DOS AGENTES:", True, PRETO), (810, 10))
    tela.blit(fonte.render("Irrigador:", True, AZUL), (810, 40))
    tela.blit(fonte.render(irrigador.ultima_acao, True, PRETO), (810, 60))
    tela.blit(fonte.render("Colhedor:", True, AMARELO), (810, 100))
    tela.blit(fonte.render(colhedor.ultima_acao, True, PRETO), (810, 120))
    tela.blit(fonte.render("Sensor:", True, CINZA), (810, 160))
    tela.blit(fonte.render(sensor.ultimas_leituras, True, PRETO), (810, 180))
    info_texto = f"Plantas Coletadas: {sum(p.coletada for p in plantas)}/20"
    tela.blit(fonte.render(info_texto, True, PRETO), (810, 220))
