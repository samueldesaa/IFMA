import pygame

VERDE = (34, 139, 34)
AZUL = (70, 130, 180)
CINZA = (169, 169, 169)

class Planta:
    def __init__(self, x, y):
        self.x, self.y = x, y
        self.maturidade = 0
        self.agua = 50
        self.coletada = False

    def atualizar(self):
        if not self.coletada and self.agua > 0:
            self.maturidade = min(100, self.maturidade + 0.1)
            self.agua -= 0.05
