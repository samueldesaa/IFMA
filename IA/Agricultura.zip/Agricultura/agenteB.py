import pygame
AMARELO = (255, 215, 0)

class Colhedor:
    def __init__(self):
        self.x, self.y = 0, 0
        self.ultima_acao = ""

    def agir(self, plantas):
        for planta in plantas:
            if planta.maturidade >= 100 and not planta.coletada:
                planta.coletada = True
                self.x, self.y = planta.x, planta.y
                self.ultima_acao = f"Colheu planta em ({planta.x}, {planta.y})"
                return
        self.ultima_acao = "Nenhuma planta colhida"
